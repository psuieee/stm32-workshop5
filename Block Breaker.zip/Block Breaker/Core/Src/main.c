/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <stdio.h>
//#include "init.h"
//#include "utils.h"
#include "ieee_bitmap.h"
#include "screen/ssd1306.h"
#include "screen/font_8x8.h"
#include "screen/font_16x16.h"
#include "accel/mpu6050.h"
#include "demos/accel_ball_demo.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char* ptr, int len) {
	for(int i = 0; i < len; i++) {
		ITM_SendChar((*ptr++));
	}
	return len;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
#define BLOCK_ROWS 3
#define BLOCK_COLS 8

typedef enum {
    WAIT_START,
    PLAYING,
    LOST_LIFE,
    RESET_LEVEL,
    GAME_OVER
} game_state_t;

void reset_blocks(int blocks[BLOCK_ROWS][BLOCK_COLS])
{
    for(int r=0;r<BLOCK_ROWS;r++)
        for(int c=0;c<BLOCK_COLS;c++)
            blocks[r][c] = 1;
}

int main(void)
{
	/* USER CODE BEGIN 1 */
	int level = 1;
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();

    ssd1306_t screen;
    ssd1306_init(&screen, &hi2c1);

    /*
    SET SPEED OF THE GAME!!!!!!!!!!!!!!! (higher number --> MORE DIFFICULT)
    Set this high for a challenge... (try increasing to 2.5f or 3.0f)
    DISCLAIMER: You may have to increase button sensitivity (under "case PLAYING")
    for higher speeds */
    float power = 2.0f;

    /* Game objects */
    int paddle_x = 50;
    int paddle_width = 25;
    int paddle_y = 60;

    int ball_x = 64;
    int ball_y = 40;
    int ball_dx = 1;
    int ball_dy = -1;
    int ball_size = 2;

    int block_width = 14;
    int block_height = 6;
    int blocks[BLOCK_ROWS][BLOCK_COLS];

    int lives = 3;

    mpu6050_init(&hi2c1,MPU_ACCEL_RANGE_2G,MPU_GYRO_RANGE_250DPS);

    game_state_t state = WAIT_START;

    reset_blocks(blocks);
    /* USER CODE END 1 */

    /* USER CODE BEGIN WHILE */
    while(1)
    {
    	/* USER CODE END WHILE */

    	/* USER CODE BEGIN 3 */
        switch(state)
        {
        	case WAIT_START:
        		// --- CLEAR SCREEN ---
        		ssd1306_fill(&screen, BLACK);

        		// --- DRAW LIVES at bottom right ---
        		// Show lives as numbers using your 8x8 font
        		for(int i=0; i<lives; i++)
        		{
        			// Draw a small heart or just a number "1" for each life
        			// Example: draw "♥" if your font supports it, else draw "O"
        			ssd1306_draw_char(&screen, &font_8x8, '.', 128 - 8 - i*8, 56);
        		}

        		// --- DRAW LEVEL at bottom left ---
        		char level_char[2];
        		level_char[0] = '0' + level;  // works for levels 1-9
        		level_char[1] = '\0';
        		ssd1306_draw_char(&screen, &font_8x8, level_char[0], 2, 56);

        		// --- DRAW PADDLE ---
        		ssd1306_fill_rect(&screen, paddle_x, paddle_y, paddle_width, 3, WHITE);

        		// --- DRAW BALL (stationary) ---
        		ssd1306_fill_rect(&screen, ball_x, ball_y, ball_size, ball_size, WHITE);

        		// --- DRAW BLOCKS ---
        		for(int r=0;r<BLOCK_ROWS;r++)
        		{
        			for(int c=0;c<BLOCK_COLS;c++)
        			{
        				if(blocks[r][c])
        				{
        					int bx = c * (block_width + 2);
        					int by = r * (block_height + 2) + 5;
        					ssd1306_fill_rect(&screen, bx, by, block_width, block_height, WHITE);
        				}
        			}
        		}



        		ssd1306_update(&screen);

        		// --- WAIT FOR BUTTON ---
        		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == GPIO_PIN_RESET ||
        				HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3) == GPIO_PIN_RESET)
        		{
        			state = PLAYING;
        		}
        		break;


        	case PLAYING:



        	    // --- INPUT ---
        		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == GPIO_PIN_RESET)
        	        paddle_x -= 2;

        	    if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3) == GPIO_PIN_RESET)
        	        paddle_x += 2;

        	    // Take inspiration from this code if you want to use accelerometer!!
        	    /*mpu6050_3DData accel_data;
        	    mpu6050_getAccelData(&accel_data);
        	    if(accel_data.y>20) paddle_x -= 2;
        	    if(accel_data.y<19) paddle_x += 2;*/

        	    if(paddle_x < 0) paddle_x = 0;
        	    if(paddle_x > 128 - paddle_width) paddle_x = 128 - paddle_width;

        	    // --- BALL PHYSICS ---
        	    ball_x += ball_dx;
        	    ball_y += ball_dy;

        	    if(ball_x <= 0 || ball_x >= 127)
        	        ball_dx = -ball_dx;

        	    if(ball_y <= 0)
        	        ball_dy = -ball_dy;

        	    /* --- PADDLE COLLISION WITH WEIGHTED REFLECTION --- */
        	    if(ball_y >= paddle_y - ball_size &&
        	       ball_y <= paddle_y + 3 &&
        	       ball_x + ball_size >= paddle_x &&
        	       ball_x <= paddle_x + paddle_width)
        	    {
        	        // Correct ball position
        	        ball_y = paddle_y - ball_size - 1;

        	        // Find hit position
        	        float relative_intersect_x = (ball_x + (ball_size / 2.0f)) - (paddle_x + (paddle_width / 2.0f));
        	        float normalized_intersect = relative_intersect_x / (paddle_width / 2.0f);

        	        // Set ball_dx
        	        ball_dx = normalized_intersect * power;

        	        // Flip y direction
        	        float total_speed = 0.5f+power;
        	        float dx_sq = ball_dx * ball_dx;

        	        if (dx_sq >= (total_speed * total_speed)) {
        	            ball_dy = -0.5f; // Keep some upward momentum
        	        } else {
        	            ball_dy = -sqrtf((total_speed * total_speed) - dx_sq);
        	        }
        	    }





        	    // --- BLOCK COLLISION ---
        	    int bricks_remaining = 0;
        	    for(int r=0;r<BLOCK_ROWS;r++)
        	    {
        	        for(int c=0;c<BLOCK_COLS;c++)
        	        {
        	            if(blocks[r][c])
        	            {
        	                int bx = c * (block_width + 2);
        	                int by = r * (block_height + 2) + 5;

        	                if(ball_x >= bx &&
        	                   ball_x <= bx + block_width &&
        	                   ball_y >= by &&
        	                   ball_y <= by + block_height)
        	                {
        	                    blocks[r][c] = 0;
        	                    ball_dy = -ball_dy;
        	                }
        	                bricks_remaining++;
        	            }
        	        }
        	    }

        	    // --- CHECK BALL FALL ---
        	    if(ball_y > 64)
        	        state = LOST_LIFE;

        	    // --- CHECK LEVEL COMPLETE ---
        	    if(bricks_remaining == 0)
        	        state = RESET_LEVEL;

        	    // --- DRAW ---
        	    ssd1306_fill(&screen, BLACK);


        	    // --- DRAW LIVES at bottom right ---
        	    for(int i=0; i<lives; i++)
        	    {
        	    	ssd1306_draw_char(&screen, &font_8x8, '.', 128 - 8 - i*8, 56);
        	    }
        	    // --- DRAW LEVEL at bottom left ---
        	    ssd1306_draw_char(&screen, &font_8x8, '0' + level, 2, 56);

        	    // draw paddle
        	    ssd1306_fill_rect(&screen, paddle_x, paddle_y, paddle_width, 3, WHITE);

        	    // draw ball
        	    ssd1306_fill_rect(&screen, ball_x, ball_y, ball_size, ball_size, WHITE);

        	    // draw bricks
        	    for(int r=0;r<BLOCK_ROWS;r++)
        	        for(int c=0;c<BLOCK_COLS;c++)
        	            if(blocks[r][c])
        	            {
        	                int bx = c * (block_width + 2);
        	                int by = r * (block_height + 2) + 5;
        	                ssd1306_fill_rect(&screen, bx, by, block_width, block_height, WHITE);
        	            }



        	    ssd1306_update(&screen);
        	    break;

            case LOST_LIFE:
                lives--;
                if(lives <= 0)
                {
                    state = GAME_OVER;
                }
                else
                {
                    // reset ball and paddle
                    ball_x = 64;
                    ball_y = 40;
                    ball_dx = 1;
                    ball_dy = -1;
                    paddle_x = 50;
                    state = WAIT_START;
                }
                break;

            case RESET_LEVEL:
                level++;              // advance level
                reset_blocks(blocks); // new bricks
                ball_x = 64;
                ball_y = 40;
                ball_dx = 1;
                ball_dy = -1;
                paddle_x = 50;
                state = WAIT_START;
                break;


            case GAME_OVER:
                ssd1306_fill(&screen, BLACK);
                ssd1306_update(&screen);

                // restart game on button press
                if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4) == GPIO_PIN_RESET ||
                   HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3) == GPIO_PIN_RESET)
                {
                    lives = 3;
                    reset_blocks(blocks);
                    ball_x = 64;
                    ball_y = 40;
                    ball_dx = 1;
                    ball_dy = -1;
                    state = WAIT_START;
                }
                break;
        }

        HAL_Delay(10);
    }
    /* USER CODE END 3 */

}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
